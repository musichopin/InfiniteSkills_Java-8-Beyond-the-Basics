
public class Dog extends Animal {

	public Dog() {
		// TODO Auto-generated constructor stub
	}

	public Dog(String name, String breed) {
		super(name, breed);
		// TODO Auto-generated constructor stub
	}

}
