
public class Driver {

	public static void main(String[] args) {
		Animal a = new Animal();
		System.out.println(a);
		Animal a2 = new Animal("Fido");
		System.out.println(a2);
	}

}
